package com.example.Anycast;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
